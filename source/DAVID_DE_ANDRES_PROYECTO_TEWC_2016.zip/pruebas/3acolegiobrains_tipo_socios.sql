INSERT INTO `3acolegiobrains`.tipo_socios (ID, TIPO) VALUES (1, 'DE NUMERO');
INSERT INTO `3acolegiobrains`.tipo_socios (ID, TIPO) VALUES (2, 'FUNDADOR');
INSERT INTO `3acolegiobrains`.tipo_socios (ID, TIPO) VALUES (3, 'DE HONOR');