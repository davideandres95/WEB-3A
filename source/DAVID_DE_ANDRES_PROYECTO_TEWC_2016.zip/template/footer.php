<footer class="footer-distributed">

    <div class="footer-left">

        <h3><span><strong>3A</strong>/</span><strong>A</strong>sociación de <strong>A</strong>ntiguos <strong>A</strong>lumnos</h3>

        <p class="footer-links">
            <a href="http://www.3acolegiobrains.tk/#home">Home</a>
            ·
            <a href="http://www.3acolegiobrains.tk/#Habout">3A</a>
            .
            <a href="http://www.3acolegiobrains.tk/#servicios">Servicios</a>
            .
            <a href="#http://www-3acolegiobrains.tk/#Junta_Directiva">Junta Directiva</a>
            .
            <a href="http://www-3acolegiobrains.tk/#Hgallery">Galeria</a>
            .
            <a href="http://www-3acolegiobrains.tk/#contact">Contact</a>
        </p>

        <p class="footer-company-name">&copy; Colegio Brains. Todos los derechos 2016</p>
    </div>

    <div class="footer-center">

        <div>
            <i class="fa fa-map-marker"></i>
            <p><span>C/ Salvia, 48 - 28109 Madrid</span> La Moraleja - Alcobendas</p>
        </div>

        <div>
            <i class="fa fa-phone"></i>
            <p>+ 34 91 650 43 00</p>
        </div>

        <div>
            <i class="fa fa-envelope"></i>
            <p><a href="mailto:antiguosalumnos@colegiobrains.com">antiguosalumnos@colegiobrains.com</a></p>
        </div>

    </div>

    <div class="footer-right">

        <p class="footer-company-about">
            <span>ASOCIACIÓN ANTIGUOS ALUMNOS COLEGIO BRAINS</span>
            Con la denominación de “ASOCIACIÓN DE ANTIGUOS ALUMNOS BRAINS”, se constituye una entidad sin ánimo de lucro, al amparo del artículo 22 CE, que
            se regirá por la Ley Orgánica 1/2002, de 22 de marzo reguladora del derecho de asociación y normas concordantes y las que en cada momento le sean
            aplicables y por los Estatutos vigentes.
        </p>

        <div class="footer-icons">

            <a href="https://www.facebook.com/Asociaci%C3%B3n-Antiguos-Alumnos-Colegio-Brains-1525714887685687/?fref=ts"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-linkedin"></i></a>
            <a href="#"><i class="fa fa-github"></i></a>

        </div>

    </div>

</footer>