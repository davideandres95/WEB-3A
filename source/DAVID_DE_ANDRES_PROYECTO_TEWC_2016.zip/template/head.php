<meta charset="utf-8" />
<meta name="author:David de Andrés" content="WEB ANTIGUOS ALUMNOS COLEGIO BRAINS" />
<title>WEB ANTIGUOS ALUMNOS COLEGIO BRAINS</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" href="favicon.ico" type="image/x-icon">
<link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">

<!-- attach CSS styles -->
<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/css/templates.css" rel="stylesheet" />
<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">

<!-- Favicon and touch icons -->
<link rel="icon" href="assets/ico/favicon.ico" type="image/x-icon">
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
<link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">