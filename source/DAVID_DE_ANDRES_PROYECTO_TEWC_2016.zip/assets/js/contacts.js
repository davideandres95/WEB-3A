/**
 * Created by David on 18/05/2016.
 */
$(function(){
    $("a[data-toggle='tooltip']").tooltip();
});